public class Main {

	public static void main(String[] args) {
		try {
			new GUI();			
		} catch (Exception e) {
			System.out.println(e);
		}

	}
}

/*
Main

+ main() : void
 */